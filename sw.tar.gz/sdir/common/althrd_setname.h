#ifndef COMMON_ALTHRD_SETNAME_H
#define COMMON_ALTHRD_SETNAME_H

void althrd_setname(const char *name);

#endif /* COMMON_ALTHRD_SETNAME_H */
